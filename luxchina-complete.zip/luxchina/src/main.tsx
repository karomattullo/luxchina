import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { LangProvider } from './i18n'
import { ShopProvider } from './store/shop'
import './index.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <LangProvider>
        <ShopProvider>
          <App />
        </ShopProvider>
      </LangProvider>
    </BrowserRouter>
  </StrictMode>,
)
